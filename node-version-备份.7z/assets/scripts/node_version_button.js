const icons = {
    delete: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>`,
    download: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
        <polyline points="7 10 12 15 17 10"></polyline>
        <line x1="12" y1="15" x2="12" y2="3"></line>
    </svg>`,
    error: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" y1="8" x2="12" y2="12"></line>
        <line x1="12" y1="16" x2="12.01" y2="16"></line>
    </svg>`,
    loading: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 12a9 9 0 1 1-6.219-8.56"></path>
    </svg>`
};

function createButtonComponent(version, isCurrent, inTable, installed) {
    // 按钮元素
    const button = document.createElement('button');
    button.className = 'node-version-button';
    button.setAttribute('data-version', version);
    button.textContent = version;
    // 根据参数自动判断状态
    const state = (inTable ? 'table.' : '') + (isCurrent ? 'current' : installed ? 'installed' : 'table');
    // 图标元素
    const icon = document.createElement('span');
    icon.className = 'button-icon';
    button.appendChild(icon);
    //更新按钮状态
    updateButtonState(button, state);
    // 点击事件处理
    button.addEventListener('click', async (event) => {
        let command;
        if (event.target.closest('.button-icon')) {
            event.stopPropagation();//阻止事件冒泡，避免重复触发
            command = nvm.uninstall(version);
        } else {
            if (button.classList.contains('installed') || button.classList.contains('current')) {
                command = nvm.use(version);
            } else {
                command = nvm.install(version);
            }
        }
        console.log('发送命令:', command);
        vscode.postMessage(command);
        updateButtonState(button, 'downloading');
        window.removeEventListener('message', handleMessage);  // 先移除旧的
        window.addEventListener('message', handleMessage);
    });
    // 监听来自扩展的消息
    const handleMessage = (event) => {
        const message = event.data;
        if (message.command && message.command.includes(version)) {
            console.log('接收到消息:', event.data);
            window.removeEventListener('message', handleMessage);
            if (message.error || (message.data && message.data.includes('error'))) {
                updateButtonState(button, 'error');
                console.error('命令执行失败:', message.error || message.data);
            } else if (message.command === nvm.uninstall(version)) {
                removeNonTableVersionButtons(version);
                setVersionButtonState(version, 'table');
                vscode.postMessage(nvm.l);
            } else if (message.command === nvm.use(version)) {
                resetCurrentButtons();
                setVersionButtonState(version, 'current');
            } else if (message.command === nvm.install(version)) {
                updateButtonState(button, 'installed');
                vscode.postMessage(nvm.l);
            }
        }
    };
    return button;
}


function updateButtonState(button, state) {
    if (button.classList.contains('table')) { state = 'table.' + state; }
    // 完全重置所有状态类名
    const allStates = ['table', 'installed', 'current', 'downloading', 'error'];
    button.classList.remove(...allStates);
    // 添加新状态类名
    if (state) {
        state.split('.').forEach(statePart => {
            button.classList.add(statePart);
        });
    }
    // 更新图标
    const icon = button.querySelector('.button-icon');
    if (icon) {
        // 完全重置所有图标类名
        const allIconStates = ['loading', 'delete', 'error', 'download'];
        icon.classList.remove(...allIconStates);

        const stateMap = {
            table: { icon: icons.download, className: 'download' },
            current: { icon: icons.delete, className: 'delete' },
            installed: { icon: icons.delete, className: 'delete' },
            downloading: { icon: icons.loading, className: 'loading' },
            error: { icon: icons.error, className: 'error' }
        };

        // 获取主要状态（处理复合状态如 table.current）
        const states = state ? state.split('.') : ['table'];
        const primaryState = states.find(s => s !== 'table') || 'table';
        const stateConfig = stateMap[primaryState] || stateMap.table;

        // 修复：使用正确的变量名 stateConfig.icon 和 stateConfig.className
        icon.innerHTML = stateConfig.icon;
        icon.classList.add(stateConfig.className);
    }
}

// 恢复所有当前状态的按钮为installed
function resetCurrentButtons() {
    console.log('恢复所有当前按钮为installed');
    const allCurrentButtons = document.querySelectorAll('.node-version-button.current,.node-version-button.table.current');
    allCurrentButtons.forEach(button => {
        updateButtonState(button, 'installed');
    });
}
//设置指定版本的按钮状态
function setVersionButtonState(version, state) {
    console.log('设置版本按钮状态:', version, state);
    const versionButtons = document.querySelectorAll(`.node-version-button[data-version="${version}"]`);
    versionButtons.forEach(button => {
        updateButtonState(button, state);
    });
}
//移除指定版本的非table按钮
function removeNonTableVersionButtons(version) {
    console.log('移除非table版本按钮:', version);
    const versionButtons = document.querySelectorAll(`.node-version-button[data-version="${version}"]`);
    versionButtons.forEach(button => {
        if (!button.classList.contains('table')) {
            button.remove();
        }
    });
}